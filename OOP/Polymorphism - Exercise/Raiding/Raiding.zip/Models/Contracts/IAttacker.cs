﻿namespace Raiding.Models.Contracts
{
    public interface IAttacker:IBaseHero
    {
    }
}
