﻿namespace Raiding.Models.Contracts
{
    public interface IDruid:IHealer
    {
    }
}
