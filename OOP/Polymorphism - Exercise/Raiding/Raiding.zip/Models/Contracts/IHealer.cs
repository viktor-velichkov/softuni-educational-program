﻿namespace Raiding.Models.Contracts
{
    public interface IHealer:IBaseHero
    {
    }
}
