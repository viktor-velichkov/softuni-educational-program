﻿namespace Raiding.Common
{
    public class GlobalConstants
    {
        public const string HEALER_CAST_MESSAGE = "{0} - {1} healed for {2}";
        public const string ATTACKER_CAST_MESSAGE = "{0} - {1} hit for {2} damage";

    }
}
