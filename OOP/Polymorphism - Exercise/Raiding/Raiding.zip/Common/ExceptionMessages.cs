﻿namespace Raiding.Common
{
    public static class ExceptionMessages
    {
        public const string INVALID_HERO_TYPE_EXCEPTION_MESSAGE = "Invalid hero!";
    }
}
