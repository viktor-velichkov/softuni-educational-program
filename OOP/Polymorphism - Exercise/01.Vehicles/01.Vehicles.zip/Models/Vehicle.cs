﻿using System;

namespace _01.Vehicles.Models
{
    public abstract class Vehicle
    {
        private double fuelQuantity;
        private double fuelConsumptionPerKm;
        public Vehicle(double fuel, double consumption)
        {
            this.FuelQuantity = fuel;
            this.FuelConsumptionPerKm = consumption;
        }
        public double FuelQuantity { get { return this.fuelQuantity; } protected set { this.fuelQuantity = value; } }
        public double FuelConsumptionPerKm { get { return this.fuelConsumptionPerKm; } protected set { this.fuelConsumptionPerKm = value; } }
        public virtual void Drive(double distance)
        {
            if (this.FuelQuantity >= distance * this.FuelConsumptionPerKm)
            {
                this.FuelQuantity -= distance * this.FuelConsumptionPerKm;
                Console.WriteLine($"{this.GetType().Name} travelled {distance} km");
            }
            else
            {
                Console.WriteLine($"{this.GetType().Name} needs refueling");
            }

        }
        public virtual void Refuel(double fuelLitres)
        {
            this.FuelQuantity += fuelLitres;
        }
        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.FuelQuantity:f2}";
        }
    }
}
