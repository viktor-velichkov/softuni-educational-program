﻿namespace _01.Vehicles.Models
{
    public class Truck : Vehicle
    {
        public Truck(double fuel, double consumption) : base(fuel, consumption)
        {
            this.FuelConsumptionPerKm += 1.6;
        }
        public override void Refuel(double fuelLitres)
        {
            this.FuelQuantity += 0.95 * fuelLitres;
        }
    }
}
