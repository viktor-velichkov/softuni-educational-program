﻿namespace _01.Vehicles.Common
{
    public class GlobalConstants
    {
    }
}
