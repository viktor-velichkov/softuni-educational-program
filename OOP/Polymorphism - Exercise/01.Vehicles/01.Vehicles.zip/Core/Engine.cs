﻿using _01.Vehicles.Models;
using System;
using System.Collections.Generic;

namespace _01.Vehicles.Core
{
    public class Engine
    {
        public void Run()
        {
            List<Vehicle> vehicles = new List<Vehicle>();
            string[] carData = Console.ReadLine().Split();            
            double carFuel = double.Parse(carData[1]);
            double carFuelConsumption = double.Parse(carData[2]);

            Vehicle car = new Car(carFuel, carFuelConsumption);
            vehicles.Add(car);

            string[] truckData = Console.ReadLine().Split();
            double truckFuel = double.Parse(truckData[1]);
            double truckFuelConsumption = double.Parse(truckData[2]);

            Vehicle truck = new Truck(truckFuel, truckFuelConsumption);
            vehicles.Add(truck);

            int lines = int.Parse(Console.ReadLine());
            for (int i = 0; i < lines; i++)
            {
                string[] command = Console.ReadLine().Split();
                string action = command[0];
                string type = command[1];
                Vehicle currentVehicle = vehicles.Find(x => x.GetType().Name == type);
                switch (action)
                {                    
                    case "Drive":
                        double distance = double.Parse(command[2]);
                        currentVehicle.Drive(distance);
                        break;
                    case "Refuel":
                        double litres = double.Parse(command[2]);
                        currentVehicle.Refuel(litres);
                        break;

                    default:
                        break;
                }
            }
            foreach (var vehicle in vehicles)
            {
                Console.WriteLine(vehicle);
            }
        }
    }
}
