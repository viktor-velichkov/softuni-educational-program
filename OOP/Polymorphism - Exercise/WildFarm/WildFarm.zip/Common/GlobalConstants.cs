﻿namespace WildFarm.Common
{
    public class GlobalConstants
    {
        
    }
}
