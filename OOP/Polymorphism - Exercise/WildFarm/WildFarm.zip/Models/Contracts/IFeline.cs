﻿namespace WildFarm.Models.Contracts
{
    public interface IFeline:IMammal
    {
        public string Breed { get; set; }
    }
}
