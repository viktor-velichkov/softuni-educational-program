﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Exceptions
{
    public class ExceptionMessages
    {
        public const string WRONG_FOOD_TYPE = "{0} does not eat {1}!";
    }
}
