﻿namespace _09.ExplicitInterfaces.Common
{
    public class GlobalConstants
    {
    }
}
