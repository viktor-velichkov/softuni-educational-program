﻿using _04.BorderControl.Core;

namespace _04.BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
