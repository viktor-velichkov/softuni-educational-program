﻿namespace _03.Telephony.Models
{
    public interface IBrowser
    {
        public string Browse(string site);
    }
}
