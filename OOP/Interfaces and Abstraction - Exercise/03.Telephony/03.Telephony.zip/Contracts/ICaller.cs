﻿namespace _03.Telephony.Models
{
    interface ICaller
    {
        public string Call(string number);
    }
}
