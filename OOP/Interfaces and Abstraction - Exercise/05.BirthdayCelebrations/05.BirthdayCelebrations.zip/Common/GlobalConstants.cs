﻿namespace _05.BirthdayCelebrations.Common
{
    public class GlobalConstants
    {
    }
}
