﻿using Microsoft.VisualBasic.CompilerServices;

namespace _07.MilitaryElite.Common
{
    public class GlobalConstants
    {
        
    }
}
