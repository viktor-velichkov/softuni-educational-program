﻿using System;

namespace _07.MilitaryElite.Exceptions
{
    class InvalidMissionStateException : Exception
    {

    }
}
