﻿using System;

namespace _07.MilitaryElite.Exceptions
{
    public class InvalidCorpsException : Exception
    {

    }
}
