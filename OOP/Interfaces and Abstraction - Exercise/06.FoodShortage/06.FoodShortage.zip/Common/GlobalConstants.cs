﻿namespace _06.FoodShortage.Common
{
    public class GlobalConstants
    {
    }
}
