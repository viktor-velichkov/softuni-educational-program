﻿using _06.FoodShortage.Core;

namespace _06.FoodShortage
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
