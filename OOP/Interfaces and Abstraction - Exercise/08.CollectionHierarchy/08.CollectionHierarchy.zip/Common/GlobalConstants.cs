﻿namespace _08.CollectionHierarchy.Common
{
    public class GlobalConstants
    {
    }
}
