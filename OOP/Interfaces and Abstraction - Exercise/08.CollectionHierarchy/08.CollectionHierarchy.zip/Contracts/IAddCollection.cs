﻿using System.Collections.Generic;

namespace _08.CollectionHierarchy.Contracts
{
    public interface IAddCollection
    {
        public int Add(string item);
    }
}
