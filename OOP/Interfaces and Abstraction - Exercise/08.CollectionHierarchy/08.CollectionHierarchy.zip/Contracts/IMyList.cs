﻿namespace _08.CollectionHierarchy.Contracts
{
    public interface IMyList : IAddRemoveCollection
    {
        public int Used { get; }
    }
}
