﻿namespace _08.CollectionHierarchy.Contracts
{
    public interface IAddRemoveCollection:IAddCollection
    {
        public string Remove();
    }
}
