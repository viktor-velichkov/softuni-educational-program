using NUnit.Framework;
using System;

[TestFixture]
public class AxeTests
{

    [Test]
    public void DoesAxeLoseDurabilityAfterAttack()
    {
        //Arrange
        Axe axe = new Axe(10, 10);
        Dummy dummy = new Dummy(100, 100);
        axe.Attack(dummy);

        //Act

        int expectedResult = 9;
        int actualResult = axe.DurabilityPoints;


        //Assert
        Assert.AreEqual(expectedResult, actualResult);
    }

    [Test]
    public void AttackWithBrokenWeapon()
    {
        //Arrange
        Axe axe = new Axe(10, -5);
        Dummy dummy = new Dummy(100, 100);
        //Act-Assert
        Assert.Throws<InvalidOperationException>(() => axe.Attack(dummy), "Axe is broken.");
    }

}