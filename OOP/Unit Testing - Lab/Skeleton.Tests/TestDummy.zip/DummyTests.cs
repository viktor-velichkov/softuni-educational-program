﻿using NUnit.Framework;
using System;

[TestFixture]
public class DummyTests
{
    [Test]
    public void DummyLosesHealthIfAttacked()
    {
        //Arrange
        Dummy dummy = new Dummy(100, 100);
        dummy.TakeAttack(50);
        //Act
        int expectedOutput = 50;
        int actualOutput = dummy.Health;

        //Assert
        Assert.That(actualOutput, Is.EqualTo(expectedOutput),
                    String.Format($"Dummy loses {actualOutput} health, instead of {expectedOutput}"));
    }
    [Test]
    public void DeadDummyThrowsExceptionIfAttacked()
    {
        //Arrange
        Dummy dummy = new Dummy(-20, 520);

        //Act-Assert
        Assert.Throws<InvalidOperationException>(() => dummy.TakeAttack(50));
    }
    [Test]
    public void DeadDummyGiveExp()
    {
        //Arrange
        Dummy dummy = new Dummy(-20, 520);

        //Act
        int expectedOutput = 520;
        int actualOutput = dummy.GiveExperience();

        //Assert
        Assert.That(actualOutput, Is.EqualTo(expectedOutput));
    }
    [Test]
    public void AliveDummyGiveExp()
    {
        //Arrange
        Dummy dummy = new Dummy(20, 520);

        //Act-Assert
        Assert.Throws<InvalidOperationException>(() => dummy.GiveExperience());
        
    }

}
