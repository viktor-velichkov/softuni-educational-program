﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleFactoryPatternDemo
{
    public class Cat : IAnimal
    {
        public Cat()
        {
            this.Name = "Gosho";
        }



        public string Name { get; private set; }
    }
}
