﻿using System;

namespace SimpleFactoryPatternDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Simple Factory pattern is used to keep the code for the creation of objects in one place, and for loose coupling between the client and business layers
            // It is responsible for creating objects

            IAnimal animal = AnimalFactory.CreateAnimal("Dog");

            Console.WriteLine(animal.Name);
        }
    }
}
