﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleFactoryPatternDemo
{
    public interface IAnimal
    {
        public string Name { get; }
    }
}
