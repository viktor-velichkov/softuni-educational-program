﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleFactoryPatternDemo
{
    public class Dog : IAnimal
    {
        public Dog()
        {
            this.Name = "Pesho";
        }



        public string Name { get; }
    }
}
