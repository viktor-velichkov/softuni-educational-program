﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleFactoryPatternDemo
{
    public class AnimalFactory
    {
        // Creates object of the desired type and returns it
        public static IAnimal CreateAnimal(string animalType)
        {
            IAnimal animal = animalType switch
            {
                "Cat" => new Cat(),
                "Dog" => new Dog(),
                _ => null
            };

            return animal;
        }
    }
}
