﻿using FluentInterfacePatternDemo.Models.Cars;
using System;
using System.Collections.Generic;
using System.Text;

namespace FluentInterfacePatternDemo
{
    public interface ICarBuilder
    {
        public ICarBuilder BuildTires(Car car);

        public ICarBuilder BuildEngine(Car car);

        public ICarBuilder BuildTransmission(Car car);
    }
}
