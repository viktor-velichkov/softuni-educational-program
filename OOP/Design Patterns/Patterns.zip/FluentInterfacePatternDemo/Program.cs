﻿using FluentInterfacePatternDemo.Models.Cars;
using FluentInterfacePatternDemo.Models.Builders;
using System;

namespace FluentInterfacePatternDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Used to chain/connect methods and allow implementation of several methods at once

            Car car = new Car();
            ICarBuilder builder = new CarBuilder();

            builder.BuildEngine(car).BuildTires(car).BuildTransmission(car);

            Console.WriteLine(car.Engine);
            Console.WriteLine(car.Tires);
            Console.WriteLine(car.Transmission);
        }
    }
}
