﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FluentInterfacePatternDemo.Models.Cars
{
    public class Car
    {
        public string Engine { get; set; }

        public string Tires { get; set; }

        public string Transmission { get; set; }
    }
}
