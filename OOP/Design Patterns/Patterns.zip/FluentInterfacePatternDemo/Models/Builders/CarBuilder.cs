﻿using FluentInterfacePatternDemo.Models.Cars;
using System;
using System.Collections.Generic;
using System.Text;

namespace FluentInterfacePatternDemo.Models.Builders
{
    public class CarBuilder : ICarBuilder
    {
        public ICarBuilder BuildEngine(Car car)
        {
            car.Engine = "V8";
            return this;
        }

        public ICarBuilder BuildTires(Car car)
        {
            car.Tires = "Michelin";
            return this;
        }

        public ICarBuilder BuildTransmission(Car car)
        {
            car.Transmission = "Automatic";
            return this;
        }
    }
}
