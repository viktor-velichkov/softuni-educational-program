﻿using AbstractFactoryPatternDemo.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern1Demo.Models
{
    public class Zebra : IGrassEating
    {
        public string Describe => "I eat grass!";
    }
}
