﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPatternDemo.Models.Contracts
{
    public interface IGrassEating
    {
        public string Describe { get; }
    }
}
