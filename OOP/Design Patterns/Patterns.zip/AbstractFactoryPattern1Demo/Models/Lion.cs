﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethodPatternDemo.Models
{
    public class Lion : ICarnivoire
    {
        public string Describe => "I eat meat!";
    }
}
