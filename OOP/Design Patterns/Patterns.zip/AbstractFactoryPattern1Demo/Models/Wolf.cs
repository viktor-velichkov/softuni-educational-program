﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethodPatternDemo.Models
{
    public class Wolf : ICarnivoire
    {
        public string Describe => "I eat meat!";
    }
}
