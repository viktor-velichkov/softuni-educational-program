﻿using AbstractFactoryPattern1Demo.Models;
using AbstractFactoryPatternDemo.Models.Contracts;
using FactoryMethodPatternDemo.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethodPatternDemo.Factories.Entities
{
    public class AfricaFactory : IAnimalFactory
    {
        public IBug GetBug()
        {
            return new Beetle();
        }

        public ICarnivoire GetCarnivoire()
        {
            return new Lion();
        }

        public IGrassEating GetGrassEating()
        {
            return new Zebra();
        }
    }
}
