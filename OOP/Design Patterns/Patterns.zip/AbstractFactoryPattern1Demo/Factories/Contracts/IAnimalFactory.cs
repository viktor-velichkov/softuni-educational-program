﻿using AbstractFactoryPatternDemo.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethodPatternDemo
{
    public interface IAnimalFactory
    {
        public ICarnivoire GetCarnivoire();

        public IGrassEating GetGrassEating();

        public IBug GetBug();
    }
}
