﻿using FactoryMethodPatternDemo;
using FactoryMethodPatternDemo.Factories.Entities;
using System;

namespace AbstractFactoryPattern1Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Abstact factory is used for creating entire group of cohesive objects/object families

            string continent = Console.ReadLine();

            IAnimalFactory factory = continent switch
            {
                "Africa" => new AfricaFactory(),
                "Europe" => new EuropeFactory(),
                _ => null
            };

            Console.WriteLine(factory.GetCarnivoire().Describe);
            Console.WriteLine(factory.GetGrassEating().Describe);
            Console.WriteLine(factory.GetBug().Describe);
        }
    }
}
