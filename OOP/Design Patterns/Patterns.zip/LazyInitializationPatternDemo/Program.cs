﻿using System;

namespace LazyInitializationPatternDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Its used for creating an object just when we use/modify it for the first time

            Lazy<Card> card = new Lazy<Card>(() => new Card("Here", "We", "Go"));

            Console.WriteLine("Before initialization");

            card.Value.Balance = 100;

            Console.WriteLine(card.Value.Balance.ToString("f2"));
        }
    }
}
