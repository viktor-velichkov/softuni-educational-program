﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LazyInitializationPatternDemo
{
    public class Card
    {
        public Card(params string[] args)
        {
            Console.WriteLine("Initialized " + string.Join(" ", args));
        }



        public int Balance { get; set; }
    }
}
