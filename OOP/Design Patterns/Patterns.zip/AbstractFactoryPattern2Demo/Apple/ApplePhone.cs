﻿using AbstractFactoryPattern2Demo.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern2Demo.Apple
{
    public class ApplePhone : IMobilePhone
    {
        public int Number { get; set; }
    }
}
