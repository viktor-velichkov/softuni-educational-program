﻿using AbstractFactoryPattern2Demo.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern2Demo.Apple
{
    public class AppleTablet : ITablet
    {
        public string OS { get; set; }
    }
}
