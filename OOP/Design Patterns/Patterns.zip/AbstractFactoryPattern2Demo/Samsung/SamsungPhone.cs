﻿using AbstractFactoryPattern2Demo.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern2Demo.Samsung
{
    public class SamsungPhone : IMobilePhone
    {
        public int Number { get; set; }
    }
}
