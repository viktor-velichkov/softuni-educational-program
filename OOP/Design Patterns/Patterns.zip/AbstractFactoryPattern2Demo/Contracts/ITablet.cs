﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern2Demo.Contracts
{
    public interface ITablet
    {
        public string OS { get; set; }
    }
}
