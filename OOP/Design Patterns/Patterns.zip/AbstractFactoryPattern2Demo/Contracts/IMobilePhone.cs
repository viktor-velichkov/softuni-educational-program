﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern2Demo.Contracts
{
    public interface IMobilePhone
    {
        public int Number { get; set; }
    }
}
