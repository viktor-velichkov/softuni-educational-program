﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern2Demo.Contracts
{
    public interface IBrandAbstractFactory
    {
        public IMobilePhone CreatePhone();

        public ITablet CreateTablet();
    }
}
