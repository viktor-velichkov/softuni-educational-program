﻿using AbstractFactoryPattern2Demo.Contracts;
using AbstractFactoryPattern2Demo.Factories;
using System;

namespace AbstractFactoryPattern2Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Abstact factory is used for creating entire group of cohesive objects/object families

            string productBrand = Console.ReadLine();

            IBrandAbstractFactory factory = productBrand switch
            {
                "Apple" => new AppleFactory(),
                "Samsung" => new SamsungFactory(),
                _ => null
            };

            Console.WriteLine(factory.CreatePhone().GetType().Name);
            Console.WriteLine(factory.CreateTablet().GetType().Name);
        }
    }
}
