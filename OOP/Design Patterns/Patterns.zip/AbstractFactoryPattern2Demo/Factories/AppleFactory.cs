﻿using AbstractFactoryPattern2Demo.Apple;
using AbstractFactoryPattern2Demo.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern2Demo.Factories
{
    public class AppleFactory : IBrandAbstractFactory
    {
        public IMobilePhone CreatePhone()
        {
            return new ApplePhone();
        }

        public ITablet CreateTablet()
        {
            return new AppleTablet();
        }
    }
}
