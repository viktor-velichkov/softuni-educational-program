﻿using AbstractFactoryPattern2Demo.Contracts;
using AbstractFactoryPattern2Demo.Samsung;
using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern2Demo.Factories
{
    public class SamsungFactory : IBrandAbstractFactory
    {
        public IMobilePhone CreatePhone()
        {
            return new SamsungPhone();
        }

        public ITablet CreateTablet()
        {
            return new SamsungTablet();
        }
    }
}
