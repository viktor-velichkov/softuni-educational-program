﻿using BuilderPatternDemo.Models.Cars;
using System;
using System.Collections.Generic;
using System.Text;

namespace BuilderPatternDemo
{
    public interface ICarBuilder
    {
        public void BuildTires(Car car);

        public void BuildEngine(Car car);

        public void BuildTransmission(Car car);


    }
}
