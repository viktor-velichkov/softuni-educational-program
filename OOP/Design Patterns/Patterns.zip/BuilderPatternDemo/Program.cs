﻿using BuilderPatternDemo.Models.Builders;
using BuilderPatternDemo.Models.Cars;
using System;

namespace BuilderPatternDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // It is used to split the creation of a complex objects in parts and can control which objects to be created

            Car car = new Car();
            ICarBuilder builder = new CarBuilder();

            builder.BuildEngine(car);
            builder.BuildTransmission(car);
            builder.BuildTires(car);

            Console.WriteLine(car.Engine);
            Console.WriteLine(car.Tires);
            Console.WriteLine(car.Transmission);
        }
    }
}
