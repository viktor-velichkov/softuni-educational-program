﻿using BuilderPatternDemo.Models.Cars;
using System;
using System.Collections.Generic;
using System.Text;

namespace BuilderPatternDemo.Models.Builders
{
    public class CarBuilder : ICarBuilder
    {
        public void BuildEngine(Car car)
        {
            car.Engine = "V8";
        }

        public void BuildTires(Car car)
        {
            car.Tires = "Michelin";
        }

        public void BuildTransmission(Car car)
        {
            car.Transmission = "Automatic";
        }
    }
}
