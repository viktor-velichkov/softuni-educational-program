﻿using FactoryMethodPatternDemo.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethodPatternDemo.Factories.Entities
{
    public class AfricaFactory : IAnimalFactory
    {
        public ICarnivoire GetCarnivoire()
        {
            return new Lion();
        }
    }
}
