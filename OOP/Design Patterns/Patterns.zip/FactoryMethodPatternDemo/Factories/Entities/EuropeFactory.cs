﻿using FactoryMethodPatternDemo.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethodPatternDemo.Factories.Entities
{
    public class EuropeFactory : IAnimalFactory
    {
        public ICarnivoire GetCarnivoire()
        {
            return new Wolf();
        }
    }
}
