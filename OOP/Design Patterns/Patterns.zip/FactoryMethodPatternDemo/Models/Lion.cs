﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethodPatternDemo.Models
{
    public class Lion : ICarnivoire
    {
        public Lion()
        {
            this.Name = nameof(Wolf);
        }



        public string Name { get; set; }
    }
}
