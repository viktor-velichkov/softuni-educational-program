﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryMethodPatternDemo.Models
{
    public class Wolf : ICarnivoire
    {
        public Wolf()
        {
            this.Name = nameof(Wolf);
        }



        public string Name { get; set; }
    }
}
