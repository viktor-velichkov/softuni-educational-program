﻿using FactoryMethodPatternDemo.Factories.Entities;
using System;

namespace FactoryMethodPatternDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Used for creating different objects, which have different implementations/requirements/conditions


            IAnimalFactory factory;

            string continent = Console.ReadLine();

            factory = continent switch
            {
                "Europe" => new EuropeFactory(),
                "Africa" => new AfricaFactory(),
                _ => null
            };

            ICarnivoire animal = factory.GetCarnivoire();

            Console.WriteLine(animal.Name);
        }
    }
}
