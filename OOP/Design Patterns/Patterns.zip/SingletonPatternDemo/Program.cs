﻿using System;

namespace SingletonPatternDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Used when only one instance of an object is needed in the application
            LoggerSingleton logger = LoggerSingleton.Instance;

            logger.LogToFile();
        }
    }
}
