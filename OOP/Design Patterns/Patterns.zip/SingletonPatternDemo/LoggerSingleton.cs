﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SingletonPatternDemo
{
    // Sealed class, which makes inheritance forbidden
    public sealed class LoggerSingleton
    {
        // Private instance, initially null
        private static LoggerSingleton instance;
        // Variable for locking
        private static object locker = new object();
        // Empty private constructor, which makes the creation of the object forbidden
        private LoggerSingleton()
        {
        }


        // Returns the instance
        public static LoggerSingleton Instance
        {
            get
            {
                // Creates the object only if the private instance property is null
                if (instance == null)
                {
                    // Locks all threads and ensures that only one instance is created at the current time
                    lock (locker)
                    {
                        // Double checks if any of the threads managed to create instance
                        if (instance == null)
                        {
                            // Creates the instance
                            Console.WriteLine("Creating instance for the first time");
                            instance = new LoggerSingleton();
                        }
                    }
                }

                return instance;
            }
        }



        public void LogToFile()
        {
            Console.WriteLine("Logged to file.");
        }
    }
}
