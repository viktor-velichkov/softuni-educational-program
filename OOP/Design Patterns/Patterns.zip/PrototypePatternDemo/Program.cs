﻿using System;

namespace PrototypePatternDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // It is used to clone objects. Used when creating an objects is expensive/hard/needs much resources
            // Shallow copy - Does not copy Reference type objects, but changes the ones from the original object. It points towards the already created objects from the original object and changes them.
            // Deep copy - Copies absolutely everything without changing the original object properties.
            // Deep copy with serialization, needs [Serializable] attribute on every reference type object in the instance

            Country country = new Country();
            country.CountryName = "Bulgaria";

            City city = new City();
            city.CityName = "Varna";

            Adress adress = new Adress();
            adress.City = city;
            adress.Country = country;
            adress.StreetAdress = "Chaika";

            Adress prototypedAdress = (Adress)adress.Clone();
            prototypedAdress.StreetAdress = "Mladost";
            prototypedAdress.City.CityName = "Sofia";

            Console.WriteLine(adress);
            Console.WriteLine(prototypedAdress);
        }
    }
}
