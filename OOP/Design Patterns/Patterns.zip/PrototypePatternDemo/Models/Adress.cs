﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace PrototypePatternDemo
{
    [Serializable]
    public class Adress : ICloneable
    {
        public City City { get; set; }

        public Country Country { get; set; }

        public string StreetAdress { get; set; }



        public object Clone()
        {
            return DeepClone<Adress>(this);
        }

        //Deep clone with Serialization
        private static T DeepClone<T>(T obj)
        {
            using (var ms = new MemoryStream())
            {
                var formatter = new BinaryFormatter();
                formatter.Serialize(ms, obj);
                ms.Position = 0;

                return (T)formatter.Deserialize(ms);
            }
        }

        public override string ToString()
        {
            return $"Country: {this.Country.CountryName}, City: {this.City.CityName}, Adress: {this.StreetAdress}";
        }
    }
}
