﻿namespace Animals.Common
{
    public class GlobalConstants
    {
    }
}
