﻿namespace Animals.Core
{
    public class Engine
    {
    }
}
