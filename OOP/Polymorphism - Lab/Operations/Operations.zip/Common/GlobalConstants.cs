﻿namespace Operations.Common
{
    public class GlobalConstants
    {
    }
}
