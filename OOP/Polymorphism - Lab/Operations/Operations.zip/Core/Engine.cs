﻿namespace Operations.Core
{
    public class Engine
    {
    }
}
