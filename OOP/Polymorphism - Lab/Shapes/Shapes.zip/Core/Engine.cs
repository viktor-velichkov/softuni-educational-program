﻿namespace Shapes.Core
{
    public class Engine
    {
    }
}
