﻿namespace Shapes.Common
{
    public class GlobalConstants
    {
    }
}
