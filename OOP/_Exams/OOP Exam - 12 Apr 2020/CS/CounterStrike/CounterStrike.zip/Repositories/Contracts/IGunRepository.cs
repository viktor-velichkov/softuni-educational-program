﻿using CounterStrike.Models.Guns.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Repositories.Contracts
{
    public interface IGunRepository : IRepository<IGun>
    {

    }
}
