﻿using CounterStrike.Models.Players.Contracts;

namespace CounterStrike.Repositories.Contracts
{
    public interface IPlayerRepository : IRepository<IPlayer>
    {
    }
}
