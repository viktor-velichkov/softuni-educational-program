﻿using System;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy 
    {
        public string StealFieldInfo(string className, params string[] fields)
        {
            Type type = Type.GetType(className);
            var instance = Activator.CreateInstance(type);

            var typeFields = type.GetFields(BindingFlags.Public
                          | BindingFlags.NonPublic
                          | BindingFlags.Instance
                          | BindingFlags.Static).Where(x => fields.Contains(x.Name));
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Class under investigation: {type.Name}");
            foreach (var item in typeFields)
            {
                sb.AppendLine($"{item.Name} = {item.GetValue(instance)}");
            }
            return sb.ToString();
        }
    }
}
